#include <iostream>
#include <iomanip>
#include <ctime>
#include <cstdlib>
#include <cmath>
#include <sstream>
#include <string>
using namespace std;
/* TODO:
Make the game GUI, HTML, or mobile?
*/
void menu_print() {
    cout << "\n\n**************************************\n\n\n";
    cout << "|||  SUPER SMASH BROS(C++ Edition) |||\n\n\n";
    cout << "**************************************\n\n";
}

int randomg() {
    return rand() % 6 +1;
}

void howToPlay(string userName, int userHp, string userM1, int userM1_dmg, string userM1_effect, string userM2, int userM2_dmg, int userEnergy) {
    cout << "\nThis game is simple. First one to 0 HP loses.\n";
    cout << "-------------------------------" << "\n|";
    cout << setw(26) << left << userName << setw(3) << left << userHp << "| <-- HP\n|";
    cout << setw(2) << left << userEnergy << " Energy" << setw(20) << "" << left << "| <-- Energies\n|";
    cout << setw(26) << left << userM1 << setw(3) << left << userM1_dmg << "| <-- Attack Dmg\n|";
    cout << "*" << setw(28) << userM1_effect << "| <-- * = Energy required/ Attack's ability\n|";
    cout << setw(26) << left << userM2 << setw(3) << left << userM2_dmg << "| <-- Attack dmg\n|";
    cout << setw(29) <<  "**" << setw(3) << left << "| <-- ** = 2 energy required\n";
    cout << "-------------------------------\n\n";
    cout << "Even: <-- Abilities that say this, will only go through with an even roll of a six sided die.\n\n";
    cout << "Every turn you will have two options:\nTry to gather energy for attacks in the 'Energy phase'\nOr attack the opponent in the 'Attack phase'.\n\n";
}

void cardView(string userName, int userHp, string userM1, int userM1_dmg, string userM1_effect, string userM1_desc, string userM2, int userM2_dmg, int userEnergy) {
    cout << "-------------------------------" << "\n|";
    cout << setw(26) << left << userName << setw(3) << left << userHp << "|\n|";
    cout << setw(2) << left << userEnergy << " Energy" << setw(20) << "" << left << "|\n|";
    cout << setw(26) << left << userM1 << setw(3) << left << userM1_dmg << "|\n|";
    cout << "*" << setw(28) << userM1_effect << "|\n|";
    cout << setw(26) << left << userM2 << setw(3) << left << userM2_dmg << "|\n|";
    cout << setw(29) <<  "**" << "|\n";
    cout << "-------------------------------\n";
    cout << userM1_desc << "\n\n";
}

void battlePrint(string userName, int userHp, string userM1, int userM1_dmg, string userM1_effect, string userM2, int userM2_dmg, int userEnergy, string cpuName, int cpuHp, string cpuM1, int cpuM1_dmg, string cpuM1_effect, string cpuM2, int cpuM2_dmg, int cpuEnergy) {
    cout << "-------------------------------" << "\n|";
    cout << setw(26) << left << userName << setw(3) << left << userHp << "|\n|";
    cout << setw(2) << left << userEnergy << " Energy" << setw(20) << "" << left << "|\n|";
    cout << setw(26) << left << userM1 << setw(3) << left << userM1_dmg << "|\n|";
    cout << "*" << setw(28) << userM1_effect << "|\n|";
    cout << setw(26) << left << userM2 << setw(3) << left << userM2_dmg << "|\n|";
    cout << setw(29) <<  "**" << "|\n";
    cout << "-------------------------------\n\n" << "VS\n\n";
    cout << "-------------------------------" << "\n|";
    cout << setw(26) << left << cpuName << setw(3) << left << cpuHp << "|\n|";
    cout << setw(2) << left << cpuEnergy << " Energy" << setw(20) << "" << left << "|\n|";
    cout << setw(26) << left << cpuM1 << setw(3) << left << cpuM1_dmg << "|\n|";
    cout << "*" << setw(28) << cpuM1_effect << "|\n|";
    cout << setw(26) << left << cpuM2 << setw(3) << left << cpuM2_dmg << "|\n|";
    cout << setw(29) <<  "**" << "|\n";
    cout << "-------------------------------\n\n";
}

int hp_control(int hp) {
    if (hp <= 0) {
        return 0;
    }
    else {
        return hp;
    }
}

int user_sonicBoom(bool sonic, int attk) {
    if (sonic) {
        return 0;
    }
    else {
        return attk;
    }
}

int cpu_sonicBoom(bool sonic, int attk) {
    if (sonic) {
        return 0;
    }
    else {
        return attk;
    }
}

int main()
{
    srand(time(0));
    const int HERO_COUNT = 7;
    string input = "";
    int menu;
    int user;
    int cpu;
    int die1 = 0; // Holds die value
    int user_move;
    int user_attk;
    bool ready = false;
    bool user_turn = false;
    bool cpu_turn = false;
    bool user_sonic = false; // Sonic Boom
    bool cpu_sonic = false;
    struct Heros{
        string name;
        int hp;
        string m1;
        int m1_dmg;
        int m1_energy;
        string m1_effect;
        string m1_desc;
        string m2;
        int m2_dmg;
        int m2_energy;
        int energy;
    };
    //Hero mario = {"Mario", 120, "Power Up", 20, 1, " Even: +1 Energy & +10 HP", "Fireball", 60, 2, 0};
    //Hero dk = {"Donkey Kong", 150, "Barrel Throw", 30, 1, " Even: Opp -1 Energy", "Smash!",80, 2 ,0};
    //Hero kingkoopa = {"King Koopa", 200, "Princess Steal", 10, 1, "Even: +1 Energy, Opp -1"}
    Heros hero[HERO_COUNT];
    hero[0].name = "Mario"; hero[0].hp = 120; hero[0].m1 = "Power Up"; hero[0].m1_dmg = 20; hero[0].m1_energy = 1; hero[0].m1_effect = " Even: +1 Energy, +20 HP"; hero[0].m1_desc = "Ability: On an even roll, you gain 1 energy and 20 HP."; hero[0].m2 = "Fireball"; hero[0].m2_dmg = 60; hero[0].m2_energy = 2;hero[0].energy = 0;
    hero[1].name = "Donkey Kong"; hero[1].hp = 140; hero[1].m1 = "Barrel Throw"; hero[1].m1_dmg = 30; hero[1].m1_energy = 1; hero[1].m1_effect = " Even: Opp -1 Energy"; hero[1].m1_desc = "Ability: On an even roll, the opponent loses 1 energy."; hero[1].m2 = "Smash!"; hero[1].m2_dmg = 60; hero[1].m2_energy = 2; hero[1].energy = 0;
    hero[2].name = "King Koopa"; hero[2].hp = 180; hero[2].m1 = "Shell Spin"; hero[2].m1_dmg = 20; hero[2].m1_energy = 1; hero[2].m1_effect = " Even: +1 Energy, Opp -1"; hero[2].m1_desc = "Ability: On an even roll, you gain 1 energy, and the opponent loses 1 energy."; hero[2].m2 = "Ground Pound"; hero[2].m2_dmg = 40; hero[2].m2_energy = 2; hero[2].energy = 0;
    hero[3].name = "Samus"; hero[3].hp = 130; hero[3].m1 = "Laser Charge"; hero[3].m1_dmg = 10; hero[3].m1_energy = 1; hero[3].m1_effect = " Zero Laser +20 dmg"; hero[3].m1_desc = "Ability: Zero Laser's base damage is increased by 20(This ability stacks).";  hero[3].m2 = "Zero Laser"; hero[3].m2_dmg = 60; hero[3].m2_energy = 2; hero[3].energy = 0;
    hero[4].name = "Sonic"; hero[4].hp = 130; hero[4].m1 = "Sonic Boom"; hero[4].m1_dmg = 20; hero[4].m1_energy = 1; hero[4].m1_effect = "Even:Opp next attack = 0 dmg"; hero[4].m1_desc = "Ability: On an even roll, Your opponents next attack won't do any damage to Sonic."; hero[4].m2 = "Spin Dash"; hero[4].m2_dmg = 60; hero[4].m2_energy = 2; hero[4].energy = 0;
    hero[5].name = "Bulbasaur"; hero[5].hp = 100; hero[5].m1 = "Leech Seed/Rare Candy"; hero[5].m1_dmg = 10; hero[5].m1_energy = 1; hero[5].m1_effect = " +10 HP, Even: Evolve into Venasaur"; hero[5].m1_desc = "Ability: Gain +10 HP. On an even roll, Bulbasaur uses a Rare Candy to evolve into Venasaur."; hero[5].m2 = "Vine Whip"; hero[5].m2_dmg = 40; hero[5].m2_energy = 2; hero[5].energy = 0;
    hero[6].name = "Venusaur"; hero[6].hp = 160; hero[6].m1 = "Growth"; hero[6].m1_dmg = 10; hero[6].m1_energy = 1; hero[6].m1_effect = " Even: +1 Energy"; hero[6].m1_desc = "Venusaur must be evolved from Bulbasaur\nAbility: On an even roll, you gain 1 energy."; hero[6].m2 = "Solar Beam"; hero[6].m2_dmg = 80; hero[6].m2_energy = 2; hero[6].energy = 0;
    // Game Menu
    menu_print();
    while (true) {
        cout << "Menu:\n1. How To Play\n2. View Hero Cards\n3. Play\n";
        getline(cin, input);

        stringstream myStream(input);
        if (myStream >> menu && menu > 0 && menu <= 3) {
            if (menu == 1) {
                howToPlay(hero[menu].name, hero[menu].hp, hero[menu].m1, hero[menu].m1_dmg, hero[menu].m1_effect, hero[menu].m2, hero[menu].m2_dmg, hero[menu].energy);
            }
            else if (menu == 2) {
                cout << "\nWhich hero card would you like to view?\n1. Mario\n2. Donkey Kong\n3. King Koopa\n4. Samus\n5. Sonic\n6. Bublasaur\n7. Venusaur\n";
                while (true) {
                    getline(cin, input);

                    stringstream myStream(input);
                    if (myStream >> user && user > 0 && user <= HERO_COUNT) {
                        user--;
                        cout << "\nYou selected to view " << hero[user].name << endl;
                        cardView(hero[user].name, hero[user].hp, hero[user].m1, hero[user].m1_dmg, hero[user].m1_effect, hero[user].m1_desc, hero[user].m2, hero[user].m2_dmg, hero[user].energy);
                        break;
                    }
                    cout << "Not a valid choice. Type the number of the hero you would to view and press enter.\n";
                }
            }
            else if (menu == 3){
                break;
            }
            else {
                cout << "Not a valid choice. Type the number of your choice and press enter.\n";
            }
        }
    }

    // Check for valid user hero selection & determine cpu hero
    while (true) {
        cout << "\nChoose your hero card:\n1. Mario\n2. Donkey Kong\n3. King Koopa\n4. Samus\n5. Sonic\n6. Bublasaur\n";
        getline(cin, input);

        stringstream myStream(input);
        if (myStream >> user && user > 0 && user <= HERO_COUNT-1) {
            user--;
            cpu = user;
            while(cpu == user) {
                cpu = rand() % HERO_COUNT;
                cout << "cpu == " << cpu << endl;
            }
            break;
        }
        cout << "Not a valid choice. Type the number of your hero and press enter.\n";
    }
    // Print cards being used
    while(true) {
        cout << "\nYou selected " << hero[user].name << "\n" << "Prepare for battle!\n";
        cout << "-------------------------------" << "\n|";
        cout << setw(26) << left << hero[user].name << setw(3) << left << hero[user].hp << "|\n|";
        cout << setw(29) <<  "" << "|\n|";
        cout << setw(26) << left << hero[user].m1 << setw(3) << left << hero[user].m1_dmg << "|\n|";
        cout << "*" << setw(28) << hero[user].m1_effect << "|\n|";
        cout << setw(26) << left << hero[user].m2 << setw(3) << left << hero[user].m2_dmg << "|\n|";
        cout << setw(29) <<  "**" << "|\n";
        cout << "-------------------------------\n\n" << "VS\n\n";
        cout << "-------------------------------" << "\n|";
        cout << setw(26) << left << hero[cpu].name << setw(3) << left << hero[cpu].hp << "|\n|";
        cout << setw(29) <<  "" << "|\n|";
        cout << setw(26) << left << hero[cpu].m1 << setw(3) << left << hero[cpu].m1_dmg << "|\n|";
        cout << "*" << setw(28) << hero[cpu].m1_effect << "|\n|";
        cout << setw(26) << left << hero[cpu].m2 << setw(3) << left << hero[cpu].m2_dmg << "|\n|";
        cout << setw(29) <<  "**" << "|\n";
        cout << "-------------------------------\n\n";
        cout << "Even roll, " << hero[user].name << " goes first. Odd, " << hero[cpu].name << " goes first.\nPress Enter to roll & start the game.\n";
        cin.get();
        break;
    }
    // Roll to see who goes first.
    die1 = randomg();
    if (die1 % 2 != 0){
        user_turn = true;
        cout << "The die rolled a " << die1 << ". " << hero[cpu].name << " will go first\n\n";
    }
    else {
        cout << "The die rolled a " << die1 << ". " << hero[user].name << " will go first\n\n";
    }
    // Battle Loop
    while (!ready) {
        // User Turn
        while (!user_turn) {
            cout << hero[user].name << " has " << hero[user].energy << " energy\nWhat would you like to do?\n1. Energy Phase(Attempt to roll even for an energy)\n2. Attack Phase(Must have an energy)\n3. View Card's\n";
            while (true) {
                getline(cin, input);

                stringstream myStream(input);
                if (myStream >> user_move && user_move > 0 && user_move <= 3) {
                    break;
                }
                cout << "Not a valid choice. Type the number of the phase you would like to go into.\n";
            }
            if (user_move == 1) {
                die1 = randomg();
                cout << endl << hero[user].name << " rolled a " << die1 << endl;
                if (die1 % 2 == 0) {
                    hero[user].energy++;
                    cout << hero[user].name << " now has " << hero[user].energy << " energy\n\n";
                    user_turn = true;
                    cpu_turn = false;
                }
                else {
                    cout << "Roll failed. " << hero[cpu].name << "'s turn\n\n";
                    user_turn = true;
                    cpu_turn = false;
                }
            }
            else if (user_move == 2) {
                if (hero[user].energy == 0) {
                    cout << "\nYou have no energy, you can't attack this turn.\n" << hero[user].name << " enters the energy phase\n";
                    die1 = randomg();
                    cout << hero[user].name <<" rolled a " << die1 << endl;
                    if (die1 % 2 == 0) {
                        hero[user].energy++;
                        cout << hero[user].name << " now has " << hero[user].energy << " energy\n\n";
                        user_turn = true;
                        cpu_turn = false;
                    }
                    else {
                        cout << "Roll failed. " << hero[cpu].name << "'s turn\n\n";
                        user_turn = true;
                        cpu_turn = false;
                    }
                }
                // Attack choice
                else {
                    cout << endl << hero[user].name << " has " << hero[user].energy << " energy to attack with.\n";
                    cout << "Which attack would you like to use?\n1. " << hero[user].m1 << " - " << hero[user].m1_energy << " Energy";
                    cout << "\n2. " << hero[user].m2 << " - " << hero[user].m2_energy << " Energy\n3. Go back\n";
                    while (true) {
                        getline(cin, input);

                        stringstream myStream(input);
                        if (myStream >> user_attk && user_attk > 0 && user_attk <= 3) {
                            break;
                        }
                        cout << "Not a valid choice.\nType the number of the attack you would like to use and press enter.\n\n";
                    }
                    if (user_attk == 1 && hero[user].energy >= hero[user].m1_energy) {
                        cout << endl << hero[user].name << " used " << hero[user].m1 << endl;
                        cout << hero[cpu].name <<  " took " << cpu_sonicBoom(cpu_sonic, hero[user].m1_dmg) << " damage.\n";
                        hero[cpu].hp -= cpu_sonicBoom(cpu_sonic, hero[user].m1_dmg);
                        cpu_sonic = false;
                        cout << hero[cpu].name << " has " << hp_control(hero[cpu].hp) << " HP left.\n\n";
                        //Checking for Mario's Power Up
                        if (user == 0) {
                            die1 = randomg();
                            if (die1 % 2 == 0) {
                                hero[user].energy++;
                                hero[user].hp += 20;
                                cout << hero[user].name << " Power Up rolled a " << die1 << ". Effect went through.\n";
                                cout << hero[user].name << " has " << hero[user].energy << " energy.\n";
                                cout << hero[user].name << " has " << hero[user].hp << " HP.\n\n";
                            }
                            else {
                                cout << hero[user].name << " Power Up rolled a " << die1 << ". Effect didn't go through.\n\n";
                            }
                        }
                        // Checking for DK's Barrel Throw
                        if (user == 1) {
                            if (hero[cpu].energy > 0) {
                                die1 = randomg();
                                if (die1 % 2 == 0) {
                                    hero[cpu].energy--;
                                    cout << "Donkey Kong rolled a " << die1 << ". Effect went through.\n";
                                    cout << hero[cpu].name << " has " << hero[cpu].energy << " energy.\n\n";
                                }
                                else {
                                    cout << "Donkey Kong's Barrel Throw rolled a " << die1 << ". Effect didn't go through.\n\n";
                                }
                            }
                        }
                        // Checking for King Koopa's Shell Spin & Venusaur's Growth
                        if (user == 2 || user == 6) {
                            die1 = randomg();
                            if (die1 % 2 == 0) {
                                hero[user].energy++;
                                cout << hero[user].name << " "  << hero[user].m1 << " rolled a " << die1 << ". Effect went through.\n";
                                cout << hero[user].name << " has " << hero[user].energy << " energy.\n";
                                // i rewrote this on user side
                                if (hero[cpu].energy > 0 && user == 2) {
                                    hero[cpu].energy--;
                                    cout << hero[cpu].name << " has " << hero[cpu].energy << " energy.\n\n";
                                }
                                else {
                                    cout << endl;
                                }
                            }
                            else {
                                    cout << hero[user].name << "'s Shell Spin rolled a " << die1 << ". Effect didn't go through.\n\n";
                            }
                        }
                        // Checking for Samus Laser Charge
                        if (user == 3) {
                            hero[user].m2_dmg += 20;
                            cout << hero[user].m2 << " now does " << hero[user].m2_dmg << " damge.\n\n";
                        }
                        // Checking for Sonic's Sonic Boom
                        if (user == 4) {
                            die1 = randomg();
                            if (die1 % 2 == 0) {
                                cout << hero[user].name << "'s Sonic Boom rolled a " << die1 << ". Effect went through.\n";
                                cout << hero[user].name << " will take no damage next turn.\n\n";
                                user_sonic = true;
                            }
                            else {
                                cout << hero[user].name << "'s Sonic Boom rolled a " << die1 << ". Effect didn't go through.\n\n";
                            }
                        }
                        // Checking for Bulbasaur's Rare Candy
                        if (user == 5) {
                            hero[user].hp += 10;
                            cout << hero[user].name << " now has " << hero[user].hp << " HP.\n\n";
                            if (die1 % 2 == 0) {
                                cout << hero[user].name << "'s Rare Candy rolled a " << die1 << ". Effect went through.\n";
                                user++;
                                hero[user].energy = hero[user-1].energy;
                                hero[user].hp += (hero[user-1].hp - 100);
                                cout << hero[user-1].name << " has evolved into " << hero[user].name << ".\n";
                                cardView(hero[user].name, hero[user].hp, hero[user].m1, hero[user].m1_dmg, hero[user].m1_effect, hero[user].m1_desc, hero[user].m2, hero[user].m2_dmg, hero[user].energy);

                            }
                            else {
                                cout << hero[user].name << "'s Rare Candy rolled a " << die1 << ". Effect didn't go through.\n\n";
                            }
                        }
                        user_turn = true;
                        cpu_turn = false;
                    }
                    else if (user_attk == 2) {
                        if (hero[user].energy >= hero[user].m2_energy) {
                            cout << endl << hero[user].name << " used " << hero[user].m2 << endl;
                            cout << hero[cpu].name <<  " took " << cpu_sonicBoom(cpu_sonic, hero[user].m2_dmg) << " damage.\n";
                            hero[cpu].hp -= cpu_sonicBoom(cpu_sonic, hero[user].m2_dmg);
                            cpu_sonic = false;
                            cout << hero[cpu].name << " has " << hp_control(hero[cpu].hp) << " HP left.\n\n";
                            user_turn = true;
                            cpu_turn = false;
                        }
                        else {
                            cout << "Not enough energy to do this attack.\n\n";
                        }
                    }
                }
            }
            // Battle Print
            else {
                battlePrint(hero[user].name, hero[user].hp, hero[user].m1, hero[user].m1_dmg, hero[user].m1_effect, hero[user].m2, hero[user].m2_dmg, hero[user].energy, hero[cpu].name, hero[cpu].hp, hero[cpu].m1, hero[cpu].m1_dmg, hero[cpu].m1_effect, hero[cpu].m2, hero[cpu].m2_dmg, hero[cpu].energy);
            }
            if (hero[cpu].hp <= 0) {
                cout << "You Win!\n";
                cpu_turn = true;
                ready = true;
            }
        }
        // CPU Turn
        while (!cpu_turn) {
            if (hero[cpu].energy == 0) {
                cout << hero[cpu].name << " enters the energy phase\n";

                die1 = randomg();

                cout << hero[cpu].name << " rolled a " << die1 << endl;
                if (die1 % 2 == 0) {
                    hero[cpu].energy++;
                    cout << hero[cpu].name << " now has " << hero[cpu].energy << " energy\n\n";
                    user_turn = false;
                    cpu_turn = true;
                }
                else {
                    cout << "Roll failed. " << hero[user].name << "'s turn\n\n";
                    user_turn = false;
                    cpu_turn = true;
                }
            }
            else if (hero[cpu].energy == 1) {
                if (hero[user].hp <= hero[cpu].m1_dmg) {
                    die1 = 1;
                }
                else {
                    die1 = randomg();
                }
                if (die1 % 2 == 0) {
                    cout << hero[cpu].name << " enters the energy phase\n";

                    die1 = randomg();

                    cout << hero[cpu].name << " rolled a " << die1 << endl;
                    if (die1 % 2 == 0) {
                        hero[cpu].energy++;
                        cout << hero[cpu].name << " now has " << hero[cpu].energy << " energy\n\n";
                        user_turn = false;
                        cpu_turn = true;
                    }
                    else {
                        cout << "Roll failed. " << hero[user].name << "'s turn\n\n";
                        user_turn = false;
                        cpu_turn = true;
                    }
                }
                else {
                    cout << endl << hero[cpu].name << " used " << hero[cpu].m1 << endl;
                    cout << hero[user].name <<  " took " << user_sonicBoom(user_sonic, hero[cpu].m1_dmg) << " damage.\n";
                    hero[user].hp -= user_sonicBoom(user_sonic, hero[cpu].m1_dmg);
                    user_sonic = false;
                    cout << hero[user].name << " has " << hp_control(hero[user].hp) << " HP left.\n\n";
                    //Checking for Mario's Power Up
                    if (cpu == 0) {
                        die1 = randomg();
                        if (die1 % 2 == 0) {
                            hero[cpu].energy++;
                            hero[cpu].hp += 20;
                            cout << hero[cpu].name << "'s Power Up rolled a " << die1 << ". Effect went through.\n";
                            cout << hero[cpu].name << " has " << hero[cpu].energy << " energy.\n";
                            cout << hero[cpu].name << " has " << hero[cpu].hp << " HP.\n\n";
                        }
                        else {
                            cout << hero[cpu].name << "'s Power Up rolled a " << die1 << ". Effect didn't go through.\n\n";
                        }
                    }
                    // Checking for DK's Barrel Throw
                    if (cpu == 1) {
                        if (hero[user].energy > 0) {
                            die1 = randomg();
                            if (die1 % 2 == 0) {
                                hero[user].energy -= 1;
                                cout << hero[cpu].name << "'s Barrel Throw rolled a " << die1 << ". Effect went through\n";
                                cout << hero[user].name << " has " << hero[user].energy << " energy.\n\n";
                            }
                            else {
                                cout << hero[cpu].name << "'s Barrel Throw rolled a " << die1 << ". Effect didn't go through.\n\n";
                            }
                        }
                    }
                    // Checking for King Koopa's Shell Spin
                    if (cpu == 2) {
                        die1 = randomg();
                        if (die1 % 2 == 0) {
                            if (hero[user].energy > 0) {
                                hero[user].energy--;
                            }
                            hero[cpu].energy++;
                            cout << hero[cpu].name << "'s Shell Spin rolled a " << die1 << ". Effect went through.\n";
                            cout << hero[cpu].name << " has " << hero[cpu].energy << " energy.\n";
                            cout << hero[user].name << " has " << hero[user].energy << " energy.\n\n";

                        }
                        else {
                                cout << hero[user].name << " Shell Spin rolled a " << die1 << ". Effect didn't go through.\n\n";
                        }
                    }
                    // Checking for Samus Laser Charge
                    if (cpu == 3) {
                        hero[cpu].m2_dmg += 20;
                        cout << hero[cpu].m2 << " now does " << hero[cpu].m2_dmg << " damge.\n\n";
                    }
                    // Checking for Sonic's Sonic Boom
                    if (cpu == 4) {
                        die1 = randomg();
                        if (die1 % 2 == 0) {
                            cout << hero[cpu].name << "'s Sonic Boom rolled a " << die1 << ". Effect went through.\n";
                            cout << hero[cpu].name << " will take no damage next turn.\n\n";
                            cpu_sonic = true;
                        }
                        else {
                            cout << hero[cpu].name << "'s Sonic Boom rolled a " << die1 << ". Effect didn't go through.\n\n";
                        }
                    }
                    user_turn = false;
                    cpu_turn = true;
                }
            }
            else if (hero[cpu].energy == 2) {
                cout << endl << hero[cpu].name << " used " << hero[cpu].m2 << endl;
                cout << hero[user].name <<  " took " << user_sonicBoom(user_sonic, hero[cpu].m2_dmg) << " damage.\n";
                hero[user].hp -= user_sonicBoom(user_sonic, hero[cpu].m2_dmg);
                user_sonic = false;
                cout << hero[user].name << " has " << hp_control(hero[user].hp) << " HP left.\n\n";
                user_turn = false;
                cpu_turn = true;
            }
            if (hero[user].hp <= 0) {
                cout << "You Lose!\n";
                user_turn = true;
                ready = true;
            }
        }
    }
    return 0;
}
